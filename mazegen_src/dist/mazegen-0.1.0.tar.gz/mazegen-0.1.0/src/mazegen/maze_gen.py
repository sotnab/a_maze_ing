# ************************************************************************* #
#                                                                           #
#                                                      :::      ::::::::    #
#  maze_gen.py                                       :+:      :+:    :+:    #
#                                                  +:+ +:+         +:+      #
#  By: wbaran <wbaran@student.42warsaw.pl>       +#+  +:+       +#+         #
#                                              +#+#+#+#+#+   +#+            #
#  Created: 2026/08/22 15:14:13 by wbaran          #+#    #+#               #
#  Updated: 2026/09/17 15:39:41 by wbaran          ###   ########.fr        #
#                                                                           #
# ************************************************************************* #

from random import Random
from sys import stderr

from .maze import Maze, Step
from .config.maze_config import MazeConfig

from .algorithms.maze_algorithm import MazeAlgorithm
from .algorithms.maze_dfs import MazeDfs
from .algorithms.maze_wilson import MazeWilson
from .algorithms.maze_prims import MazePrims
from .algorithms.maze_solver import MazeSolver

from .types import MazeData, Cell, Grid
from .constants import NORTH, EAST, SOUTH, WEST, ALL_WALLS, PATTERN_42


class MazeGen:
    """Generate mazes, solve them, and save them to disk."""

    def dfs(self, config: MazeConfig) -> Maze:
        """Generate a maze with the DFS algorithm."""
        return self.generate(MazeDfs, config)

    def wilson(self, config: MazeConfig) -> Maze:
        """Generate a maze with Wilson's algorithm."""
        return self.generate(MazeWilson, config)

    def prims(self, config: MazeConfig) -> Maze:
        """Generate a maze with Prim's algorithm."""
        return self.generate(MazePrims, config)

    def generate(
        self, maze_algorithm: type[MazeAlgorithm], config: MazeConfig
    ) -> Maze:
        """Run a generator and return the finished maze."""

        random = Random(config.seed)
        blocked = self.get_42_cells(config)

        grid = self.create_grid(config.width, config.height)
        algorithm = maze_algorithm(grid, blocked, random, config.entry)

        steps: list[Step]

        if config.perfect:
            steps = algorithm.generate()

        if not config.perfect:
            while True:
                algorithm.generate()
                steps = algorithm.remove_dead_ends()

                if algorithm.independent_loops() > 1:
                    break

                grid = self.create_grid(config.width, config.height)
                algorithm = maze_algorithm(grid, blocked, random, config.entry)

        solver = MazeSolver(grid, config.entry, config.exit)

        solution = solver.solve_maze()

        data = self.grid_to_hex(grid)

        maze = Maze(
            data,
            config.width,
            config.height,
            config.entry,
            config.exit,
            solution,
            steps,
        )

        return maze

    def save_to_file(self, maze: Maze, filename: str) -> None:
        """Write the maze data and solution to a text file."""

        with open(filename, "w") as out_file:

            for line in maze.data:
                out_file.write(line + "\n")

            out_file.write("\n")

            out_file.write(",".join(map(str, maze.entry)) + "\n")
            out_file.write(",".join(map(str, maze.exit)) + "\n")

            out_file.write(MazeSolver.path_to_directed(maze.solution) + "\n")

    def number_of_walls(self, walls: int) -> int:
        """Count active walls in a cell value."""
        count = 0

        for direction in [NORTH, EAST, SOUTH, WEST]:
            if walls & direction > 0:
                count += 1

        return count

    def create_grid(self, width: int, height: int) -> Grid:
        """Create a fully blocked grid for maze generation."""

        return [[ALL_WALLS for _ in range(width)] for _ in range(height)]

    def grid_to_hex(self, grid: Grid) -> MazeData:
        """Convert the grid to hexadecimal rows."""
        result = []

        for row in grid:
            hex_row = ""

            for cell in row:
                hex_row += format(cell, "X")

            result.append(hex_row)

        return result

    def get_42_cells(self, config: MazeConfig) -> list[Cell]:
        """Return cells used to draw the 42 pattern."""

        pattern_height = len(PATTERN_42)
        pattern_width = len(PATTERN_42[0])

        if config.width < pattern_width + 2:
            print("Maze is too small for the 42 pattern", file=stderr)
            return []

        if config.height < pattern_height + 2:
            print("Maze is too small for the 42 pattern", file=stderr)
            return []

        reserved = [config.entry, config.exit]

        if not config.perfect:
            reserved.append((config.width // 2, config.height // 2))

        pattern_x = config.width // 2 - pattern_width // 2
        pattern_y = config.height // 2 - pattern_height // 2

        positions = [(pattern_x, pattern_y)]

        for start_y in range(1, config.height - pattern_height):
            for start_x in range(1, config.width - pattern_width):
                position = (start_x, start_y)

                if position != (pattern_x, pattern_y):
                    positions.append(position)

        for start_x, start_y in positions:
            cells = []
            valid_position = True

            for row in range(pattern_height):
                for col in range(pattern_width):
                    if PATTERN_42[row][col] != "X":
                        continue

                    x = start_x + col
                    y = start_y + row
                    cell = (x, y)

                    if cell in reserved:
                        valid_position = False
                        break

                    cells.append(cell)

                if not valid_position:
                    break

            if valid_position:
                return cells

        print("Cannot place the 42 pattern", file=stderr)

        return []
