# ************************************************************************* #
#                                                                           #
#                                                      :::      ::::::::    #
#  maze_prims.py                                     :+:      :+:    :+:    #
#                                                  +:+ +:+         +:+      #
#  By: wbaran <wbaran@student.42warsaw.pl>       +#+  +:+       +#+         #
#                                              +#+#+#+#+#+   +#+            #
#  Created: 2026/09/06 01:12:57 by wbaran          #+#    #+#               #
#  Updated: 2026/09/17 12:45:21 by wbaran          ###   ########.fr        #
#                                                                           #
# ************************************************************************* #

from random import Random

from .maze_algorithm import MazeAlgorithm
from ..types import Cell, Grid, Step


class MazePrims(MazeAlgorithm):
    """Generate a maze using Prim's algorithm."""

    def __init__(
        self,
        grid: Grid,
        blocked: list[Cell],
        random: Random,
        entry: Cell,
    ) -> None:
        """Initialize the Prim maze generator."""

        super().__init__(grid, blocked, random, entry)

    def generate(self) -> list[Step]:
        """Build a maze using Prim's growing-tree approach."""

        maze_cells = set([self.entry])
        unfinished_cells = [self.entry]

        while len(unfinished_cells) > 0:

            cell = self.random.choice(unfinished_cells)
            neighbours = self.get_neighbours_excluding(cell, maze_cells)

            if len(neighbours) == 0:
                unfinished_cells.remove(cell)
                continue

            next_cell = self.random.choice(neighbours)

            self.open_wall(cell, next_cell)

            unfinished_cells.append(next_cell)
            maze_cells.add(next_cell)

        return self.steps

    def get_neighbours_excluding(
            self, cell: Cell, excluded: set[Cell]) -> list[Cell]:
        """Return neighbours that are not already part of the maze."""

        neighbours = self.get_neighbours(cell)

        return list(filter(lambda cell: cell not in excluded, neighbours))
